package com.wifi_camera.mylibrary;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


import com.joyhonest.wifination.JH_GLSurfaceView;
import com.joyhonest.wifination.wifination;

import org.simple.eventbus.EventBus;
import org.simple.eventbus.Subscriber;

import java.io.File;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {



    private final String TAG = "MainActivity";


    boolean  bExitTest;

    Button Snap_Btn;
    Button Record_Btn;
    Button Stop_Btn;
    Button Flip_Btn;

    Button Read_btn;
    Button Write_btn;


    boolean  bFlip=false;

    boolean bSetDisp = false;

    private  Handler  handler_cmd;
    private  Runnable   Runnable_Cmd;


    private ImageView  imageView;



    private HandlerThread thread1;
    Handler    openHandler;
    Runnable   openRunnable = new Runnable() {
        @Override
        public void run() {
                String str = "";
                wifination.naSetRevBmp(true);
                wifination.naInit(str);
                bGetImage = false;
        }
    };

    int nLedMode=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        F_CreateLocalDir();      //建立 保存 相片和 视频的目录
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);



        thread1 = new HandlerThread("MyHandlerThread");
        thread1.start(); //创建一个HandlerThread并启动它
        openHandler = new Handler(thread1.getLooper());
        handler_cmd = new Handler(thread1.getLooper());
        Runnable_Cmd = new Runnable() {
            @Override
            public void run() {
                F_SentCmd();      //从这里发送飞控命令
                handler_cmd.postDelayed(this,20);  //20ms发送一次控制命令
            }
        };


        Snap_Btn = (Button) findViewById(R.id.photo);
        Record_Btn = (Button) findViewById(R.id.Record);
        Stop_Btn = (Button) findViewById(R.id.stop);
        Flip_Btn= (Button) findViewById(R.id.Flip);
        Read_btn = findViewById(R.id.Read_btn);
        Write_btn = findViewById(R.id.Write_btn);



        imageView = (ImageView)findViewById(R.id.imageView);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageClick();
            }
        });



        Snap_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snap_Btn.setTextColor(0xFFFF0000);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Snap_Btn.setTextColor(0xFF000000);
                    }
                },200);
                String recFilename =getFileNameFromDate(false,true);
                wifination.naSnapPhoto(recFilename,wifination.TYPE_ONLY_PHONE);

            }
        });
        Record_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(wifination.isPhoneRecording())
                {
                    wifination.naStopRecord_All();
                }
                else
                {
                    String recFilename = getFileNameFromDate(true, true);
                    wifination.naStartRecord(recFilename, wifination.TYPE_ONLY_PHONE);
                }



            }
        });

        Stop_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                F_BacktStartActivity();

            }
        });
        Flip_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bFlip = !bFlip;
                wifination.naSetFlip(bFlip);
            }
        });


        Read_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //wifination.naGetLedPWM();       // Read LED brightness, retrun  status  by  onGetLed
                //wifination.naGetFirmwareVersion();   //Read Firmware，  return  version info  by  onGetFirmwareVersion
                //wifination.naGetBattery();   //Read battery ststus,   return battery status by onGetBattery
                wifination.naGetLedMode();
            }
        });


        Write_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //wifination.naSetLedPWM((byte)20);  //Set Led Brightness.
                if(nLedMode==0)
                {
                    nLedMode = 1;
                    Toast toast = Toast.makeText(MainActivity.this, "设定模式1", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER,0, 0);
                    toast.show();
                }
                else
                {
                    nLedMode = 0;
                    Toast toast = Toast.makeText(MainActivity.this, "设定模式0", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER,0, 0);
                    toast.show();
                }
                wifination.naSetLedMode(nLedMode);
            }
        });


        imageView.setVisibility(View.VISIBLE);

        wifination.appContext=getApplicationContext();  // getApplicationContext();
        F_OpenStream();
        EventBus.getDefault().register(this);  // important！！！
    }


    private  void ImageClick()
    {
        if(bGetImage)
        {
            wifination.naStartAdjFocus(100,100);  //x  y  focus coordinate， you can modify it
        }
    }


    byte[] cmd = new byte[5];
    private  void F_SentCmd()
    {
       //wifination.naSentCmd(cmd,5);  //根据不同的飞控模块来调整发送飞控数据。。。
    }

    private  void F_BacktStartActivity()
    {
        bExitTest=true;
        wifination.naStopRecord_All();
        wifination.naStop();
        Intent mainIntent = new Intent(MainActivity.this, StartActivity.class);
        startActivity(mainIntent);
        finish();

    }





    @Override
    public void onBackPressed() {
        super.onBackPressed();
        F_BacktStartActivity();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);    // important！！！
        openHandler.removeCallbacksAndMessages(null);
        handler_cmd.removeCallbacksAndMessages(null);
        thread1.quit();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    private  void F_OpenStream() {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                openHandler.removeCallbacksAndMessages(null);
                openHandler.postDelayed(openRunnable,25);
            }
        }, 30);

    }





    public String getFileNameFromDate(boolean bVideo, boolean blocal)
    {
        Calendar calendar = Calendar.getInstance();
        int Year = calendar.get(Calendar.YEAR);
        int Month = calendar.get(Calendar.MONTH) + 1;
        int Day = calendar.get(Calendar.DAY_OF_MONTH);
        int Hour = calendar.get(Calendar.HOUR_OF_DAY);
        int Min = calendar.get(Calendar.MINUTE);
        int Sec = calendar.get(Calendar.SECOND);
        String StroragePath = "";
        if (blocal) {
            StroragePath = sLocalPhoto;
            if (bVideo)
                StroragePath = sLocalVideo;
        } else {
            StroragePath = sRemotePhoto;
            if (bVideo)
                StroragePath = sRemoteVideo;
        }
        String ext = "mp4";
        if (!bVideo) {
            ext = "png";
        }
        String recDir = StroragePath;  //String.format("%s/%s/%s", StroragePath, "Joyhonest/Wifi-Camera",sdir);
        File dirPath = new File(recDir);
        if (!dirPath.exists()) {
            dirPath.mkdirs();
        }
        String recPath = String.format("%s/%04d-%02d-%02d-%02d%02d%02d.%s", recDir, Year, Month, Day, Hour, Min, Sec,ext);
        return recPath;
    }


    public String sRemotePhoto=null;
    public String sRemoteVideo=null;
    public String sLocalPhoto=null;
    public String sLocalVideo=null;

    public void F_CreateLocalDir() {
        boolean bRemote = false;
        String StroragePath = "";
        String sVendor;
        sVendor="ABR_WIFI";

        if (sVendor.length() != 0)
        {

            try {
                StroragePath = Storage.getNormalSDCardPath();
            } catch (Exception e) {
                return;
            }
            if (StroragePath.length() == 0) {
                StroragePath = Storage.getNormalSDCardPath();
            }
            String recDir;
            File fdir;
            if (bRemote) {
                recDir = String.format("%s/%s/SD-Demo_Photo", StroragePath, sVendor);
                sRemotePhoto = recDir;
                fdir = new File(recDir);
                if (!fdir.exists()) {
                    fdir.mkdirs();
                }
                recDir = String.format("%s/%s/SD-Demo_Video", StroragePath, sVendor);
                sRemoteVideo = recDir;
                fdir = new File(recDir);
                if (!fdir.exists()) {
                    fdir.mkdirs();
                }
            }

            recDir = String.format("%s/%s/Demo_Video", StroragePath, sVendor);
            sLocalVideo = recDir;
            fdir = new File(recDir);
            if (!fdir.exists()) {
                fdir.mkdirs();
            }
            recDir = String.format("%s/%s/Demo_Photo", StroragePath, sVendor);
            sLocalPhoto = recDir;
            fdir = new File(recDir);
            if (!fdir.exists()) {
                fdir.mkdirs();
            }
        }

    }



    //SDK通过Android EventBus来传递 模块状态。@Subscriber(tag= "SDStatus_Changed")
    //模块状态改变，SDStatus_Changed(Integer  nStatusA) 会自动调用，您在这函数中处理相关逻辑即可
    //        //#define  bit0_OnLine            1
    //        //#define  bit1_LocalRecording    2
    //        //#define  SD_Ready               4
    //        //#define  SD_Recroding           8
    //        //#define  SD_Photo               0x10
    @Subscriber(tag= "SDStatus_Changed")
    private  void SDStatus_Changed(Integer  nStatusA)
    {
        int nStatus = nStatusA;

        if((nStatus & 0x0002)!=0)
        {
            Record_Btn.setTextColor(0xFFFF0000);  //Recording
        }
        else
        {
            Record_Btn.setTextColor(0xFF000000); //Stoprecording
        }
    }



    //如果 wifination.naSetRevBmp(true);  每一帧图片在  ReviceBMP 中传到应用层。


    boolean  bGetImage = false;

    @Subscriber(tag = "ReceiveBMP")
    private  void ReceiveBMP(Bitmap bmp)
    {
        /*
            如果之前 naSetREvBmp(true);
            那么，SDK就不会显示视频，而是把每一帧发送到此，由用户应用来处理。
            （注意，在此要尽快处理，不要太耗时，否则会影响显示的流畅度)）
         */
        bGetImage = true;
        imageView.setImageBitmap(bmp);


    }

    @Subscriber(tag="GP4225_GetKey")       //设备上的按键
    private void GP4225_GetKey(byte []m)
    {
        Log.e(TAG,"Key ="+m[1]);
    }



    @Subscriber(tag="Key_Pressed")       //设备上的按键
    private void Key_Pressed(Integer m)
    {
        Log.e(TAG,"Key = "+m);
        //n ！=0 为按键值。
        //n = 0 按键松开
        // 在这里 根据键值 来做不同功能。。。。。。.....
    }



    @Subscriber(tag = "onGetLed")
    private  void onGetLed(Integer nLed)
    {
        Log.e(TAG, "LedPWM = " + nLed);
    }
    @Subscriber(tag = "onGetBattery")
    private  void onGetBattery(Integer battery)
    {
        Log.e(TAG, "Baggery = " + battery);
    }

    @Subscriber(tag = "onGetWiFiSSID")
    private  void onGetWiFiSSID(String sSSid)
    {
        Log.e(TAG, " wifiSSid = " + sSSid);
    }
    @Subscriber(tag = "onGetFirmwareVersion")
    private  void onGetFirmwareVersion(String sVersion)
    {
        Log.e(TAG, " sVersion= " + sVersion);
    }
    @Subscriber(tag = "onGetLedMode")
    private void onGetLedMode(Integer nMode)
    {
        String str = "读取到模式 = "+nMode;
        Toast toast = Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER,0, 0);
        toast.show();
        Log.e(TAG, " LedMode= " + nMode);
    }






}